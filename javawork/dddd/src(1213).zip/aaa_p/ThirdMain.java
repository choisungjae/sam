package aaa_p;

public class ThirdMain {

	public static void main(String[] args) {
		
		
		System.out.println("세번째 이지롱");

	}

}
