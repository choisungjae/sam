package pac_2;

public class GGG {
	public String t1 = "pac_2.GGG.t1";
}
