package pac_2;

public class KKK {
	public String t1 = "pac_2.KKK.t1";
}
