package pac_2.sub;

public class JJJ {
	public String t1 = "pac_2.sub.JJJ.t1";
}
