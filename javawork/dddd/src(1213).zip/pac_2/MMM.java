package pac_2;

class MMM {
	public String t1 = "pac_2.MMM.t1";
}

/*
public class QQQ {
	public String t1 = "pac_2.QQQ.t1";
}
*/