package pac_2;

public class EEE {
	public String t1 = "pac_2.EEE.t1";
}
