package basic_p;

public class ReadMain {

	public static void main(String[] args) throws Exception {
		System.out.println("나는무너");
		System.out.print("나는상어");
		System.out.println("나는고래");
		System.out.println();
		//System.out.print();
		System.out.println("나는새우");
		System.in.read();
	}

}
