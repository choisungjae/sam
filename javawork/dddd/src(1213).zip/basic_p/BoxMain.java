package basic_p;

public class BoxMain {

	public static void main(String[] args) {

		System.out.println("  +---------------------------------+");
		System.out.println(" /\t\t\t\t   /|");
		System.out.println("+---------------------------------+ |");
		System.out.println("|\t\t\t\t  | |");
		System.out.println("|\t─\t\t─\t  | |");
		System.out.println("|\t●\t\t●\t  | |");
		System.out.println("|\t\t▽\t\t  | |");
		System.out.println("|\t\t\t\t  | +");
		System.out.println("|\t\t\t\t  |/");
		System.out.println("+---------------------------------+");

	}

}
