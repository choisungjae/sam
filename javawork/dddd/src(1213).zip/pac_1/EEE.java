package pac_1;

public class EEE {
	public String t1 = "pac_1.EEE.t1";
}
