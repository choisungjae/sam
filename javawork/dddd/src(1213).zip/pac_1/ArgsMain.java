package pac_1;

import java.util.Arrays;

public class ArgsMain {

	public static void main(String[] args) {

		System.out.println("ArgsMain 실행");
		System.out.println("갯수 : "+args.length);
		System.out.println("args : "+Arrays.toString(args));
		System.out.println("args[1] : "+args[1]);
	}

}
