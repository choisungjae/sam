package pac_1;

public class BBB {
	String t1 = "pac_1.BBB.t1";
}
class CCC {
	String t1 = "pac_1.CCC.t1";
}