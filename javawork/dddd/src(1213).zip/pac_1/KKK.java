package pac_1;

public class KKK {
	public String t1 = "pac_1.KKK.t1";
}
