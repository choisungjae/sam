package dynamic_p;

public interface InB {
	String f = "InB의f";
	String h = "InB의h";
	void meth_1();
	void meth_4();
}
